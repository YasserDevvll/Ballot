//
//  cellTableViewCell.swift
//  baloot
//
//  Created by mac on 1‏/2‏/2018.
//  Copyright © 2018 baloot. All rights reserved.
//

import UIKit

class cell: UITableViewCell {

    
    
    @IBOutlet weak var LNA: UILabel!
    
    
    @IBOutlet weak var LHM: UILabel!
    

}
